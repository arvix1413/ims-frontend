var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__a3678daf._.js")
R.c("server/chunks/ssr/[root-of-the-server]__a2047e8e._.js")
R.m(76513)
module.exports=R.m(76513).exports
