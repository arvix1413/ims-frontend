var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/[root-of-the-server]__a3678daf._.js")
R.c("server/chunks/ssr/[root-of-the-server]__a2047e8e._.js")
R.c("server/chunks/ssr/65fad_next_50bc2535._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/65fad_5c1a88fe._.js")
R.m(5947)
module.exports=R.m(5947).exports
