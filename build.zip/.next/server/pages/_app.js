var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__0864329f._.js")
R.m(82136)
module.exports=R.m(82136).exports
