var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__efbe3e79._.js")
R.c("server/chunks/[root-of-the-server]__00f4e269._.js")
R.m(12259)
R.m(17940)
module.exports=R.m(17940).exports
