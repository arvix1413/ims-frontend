module.exports=[19324,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},94820,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(19324).default,width:256,height:256}}];

//# sourceMappingURL=ims-frontend_src_app_e56299ca._.js.map