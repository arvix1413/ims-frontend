globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/a594be1308790488.js",
      "static/chunks/6fa5ae4bf8c08d45.js",
      "static/chunks/turbopack-ea249b0a9c1a2ad0.js"
    ],
    "/_error": [
      "static/chunks/b465d92d1271270d.js",
      "static/chunks/6fa5ae4bf8c08d45.js",
      "static/chunks/turbopack-9df649d25f773c97.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/126e631db0894d58.js",
    "static/chunks/73cd0facc6d37821.js",
    "static/chunks/6f347f24038c5169.js",
    "static/chunks/0332e6f9a5e90a09.js",
    "static/chunks/turbopack-a6613abfddad5107.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];