__turbopack_load_page_chunks__("/_error", [
  "static/chunks/b465d92d1271270d.js",
  "static/chunks/6fa5ae4bf8c08d45.js",
  "static/chunks/turbopack-9df649d25f773c97.js"
])
