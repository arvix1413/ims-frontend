__turbopack_load_page_chunks__("/_app", [
  "static/chunks/a594be1308790488.js",
  "static/chunks/6fa5ae4bf8c08d45.js",
  "static/chunks/turbopack-ea249b0a9c1a2ad0.js"
])
